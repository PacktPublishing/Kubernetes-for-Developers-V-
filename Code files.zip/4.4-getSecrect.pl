#!/usr/bin/perl

my $token = $1 if ( `kubectl get sa service1 -n thenamespace -o json |grep token` =~ /\"name\"\: \"(.*)\"/);
#my $ca = $1 if (`kubectl get secret $token -n thenamespace -o json|grep '"token": '`=~ /\"\: \"(.*)\"/);
my $ca = $1 if (`kubectl get secret $token -n thenamespace -o json|grep '"ca.crt": '`=~ /\"\: \"(.*)\"/);

print $ca;
